const path = require('path');
const fs = require('fs');
const multer = require('multer');

const makeDirIfNotExists = (dir) => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
};

const imageFileFilter = (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif/;
    const ext = path.extname(file.originalname).toLowerCase();
    const mimetype = allowed.test(file.mimetype);
    const extname = allowed.test(ext);
    if (mimetype && extname) return cb(null, true);
    cb(new Error('Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif)'));
};

const storageFor = (subfolder) => multer.diskStorage({
    destination: (req, file, cb) => {
        const dest = path.join(__dirname, '..', 'resources', 'images', subfolder);
        makeDirIfNotExists(dest);
        cb(null, dest);
    },
    filename: (req, file, cb) => {
        const name = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
        cb(null, name);
    }
});

const avatarUpload = multer({
    storage: storageFor('avatars'),
    fileFilter: imageFileFilter,
    limits: { fileSize: 5 * 1024 * 1024 } // 5MB
}).single('avatar');

const imagesUpload = multer({
    storage: storageFor('gallery'),
    fileFilter: imageFileFilter,
    limits: { fileSize: 5 * 1024 * 1024 } // 5MB mỗi file
}).array('images', 10); // tối đa 10 ảnh

module.exports = {
    avatarUpload,
    imagesUpload,
    // nếu cần factory generic:
    uploadAFileWithField: function (field) {
        return multer({ storage: storageFor('tmp'), fileFilter: imageFileFilter }).single(field);
    },
    uploadMultiFilesWithField: function (field, max = 10) {
        return multer({ storage: storageFor('tmp'), fileFilter: imageFileFilter }).array(field, max);
    }
};
