module.exports = {
    MESSAGE_ERROR_VALIDATOR_EMAIL:"email phai co dang xxx@domain",
    MESSAGE_ERROR_VALIDATOR_PASSWORD:"password phai dai it nhat %d ki tu, va co it nhat %d ki tu dac biet, %d chu viet thuong, %d chu viet hoa, %d so ",
    MESSAGE_ERROR_VALIDATOR_USERNAME: "username khong chua ki tu dac biet"
}