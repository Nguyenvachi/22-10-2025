const express = require('express');
const router = express.Router();
const path = require('path');

const uploadHandler = require('../utils/uploadHandler');
const { avatarUpload, imagesUpload } = uploadHandler;
const authHandler = require('../utils/authHandler');
const User = require('../schemas/users');
const Role = require('../schemas/roles');

console.log('uploadHandler:', !!uploadHandler);
console.log('avatarUpload:', !!avatarUpload);
console.log('imagesUpload:', !!imagesUpload);
console.log('authHandler:', !!authHandler);
console.log('Authentication:', typeof authHandler.Authentication);

// GET users listing
router.get('/', async function(req, res, next) {
  let allUsers = await User.find({isDeleted:false}).populate({
    path: 'role',
    select:'name'
  });
  res.send({ success:true, data:allUsers });
});

router.get('/:id', async function(req, res, next) {
  try {
    let getUser = await User.findById(req.params.id);
    if (!getUser || getUser.isDeleted) throw new Error("ID not found");
    res.send({ success:true, data:getUser });
  } catch (error) {
     res.send({ success:false, data:error.message || error });
  }
});

router.post('/', async function(req, res, next) {
  let roleName = req.body.role ? req.body.role : "USER";
  let role = await Role.findOne({name: roleName});
  let roleId = role ? role._id : undefined;
  let newUser = new User({
    username: req.body.username,
    email: req.body.email,
    password: req.body.password,
    role: roleId
  });
  await newUser.save();
  res.send({ success:true, data:newUser });
});

router.put('/:id', async function(req, res, next) {
  let user = await User.findById(req.params.id);
  if (!user) return res.status(404).send({ success:false, message: 'User not found' });
  user.email = req.body.email ? req.body.email : user.email;
  user.fullName = req.body.fullName ? req.body.fullName : user.fullName;
  user.password = req.body.password ? req.body.password : user.password;
  await user.save();
  res.send({ success:true, data:user });
});

// Upload avatar (single) - dùng authHandler.Authentication (tên đúng)
router.post('/avatar', authHandler.Authentication, (req, res) => {
  avatarUpload(req, res, async (err) => {
    if (err) return res.status(400).json({ success: false, message: err.message || 'Upload lỗi' });
    if (!req.file) return res.status(400).json({ success: false, message: 'Chưa gửi file avatar' });
    try {
      const avatarPath = path.join('resources','images','avatars', req.file.filename).replace(/\\/g,'/');
      await User.findByIdAndUpdate(req.userId || (req.user && req.user._id), { avatar: avatarPath });
      return res.json({ success: true, avatar: avatarPath });
    } catch (e) {
      return res.status(500).json({ success: false, message: 'Lỗi server' });
    }
  });
});

// Upload gallery (multiple)
router.post('/gallery', authHandler.Authentication, (req, res) => {
  imagesUpload(req, res, async (err) => {
    if (err) return res.status(400).json({ success: false, message: err.message || 'Upload lỗi' });
    if (!req.files || !req.files.length) return res.status(400).json({ success: false, message: 'Chưa gửi file' });
    try {
      const files = req.files.map(f => path.join('resources','images','gallery', f.filename).replace(/\\/g,'/'));
      await User.findByIdAndUpdate(req.userId || (req.user && req.user._id), { $push: { images: { $each: files } } });
      return res.json({ success: true, files });
    } catch (e) {
      return res.status(500).json({ success: false, message: 'Lỗi server' });
    }
  });
});

module.exports = router;
